class ChatCompraEstadoModel {
  dynamic idCompra;
  dynamic estado;

  ChatCompraEstadoModel({
    this.idCompra,
    this.estado,
  });
}
