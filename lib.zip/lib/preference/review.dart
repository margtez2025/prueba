// import 'package:in_app_review/in_app_review.dart';

class Review {
  // final InAppReview _inAppReview = InAppReview.instance;

  Future<void> requestReview(String url) async {
    // if (await _inAppReview.isAvailable()) {
    //   if (url == 'APP') {
    //     _inAppReview.requestReview();
    //   } else {
    //     _inAppReview.openStoreListing(appStoreId: Sistema.appStoreId);
    //   }
    // }
  }
}
