class ChatViajeEstadoModel {
  dynamic idViaje;
  dynamic estado;

  ChatViajeEstadoModel({
    this.idViaje,
    this.estado,
  });
}
