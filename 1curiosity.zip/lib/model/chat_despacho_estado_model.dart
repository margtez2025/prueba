class ChatDespachoEstadoModel {
  dynamic idDespacho;
  dynamic estado;

  ChatDespachoEstadoModel({
    this.idDespacho,
    this.estado,
  });
}
